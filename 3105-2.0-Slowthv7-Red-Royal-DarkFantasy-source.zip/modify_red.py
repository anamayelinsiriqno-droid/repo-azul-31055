from pathlib import Path
import colorsys
from PIL import Image, ImageEnhance
root=Path('/mnt/data/redwork/ThreeOneOSFive')

def hue_to_red(src, dst, target_h=0.985):
    im=Image.open(src).convert('RGBA')
    px=im.load()
    for y in range(im.height):
        for x in range(im.width):
            r,g,b,a=px[x,y]
            mx=max(r,g,b); mn=min(r,g,b)
            if mx==0 or mx-mn < 8:
                continue
            h,s,v=colorsys.rgb_to_hsv(r/255,g/255,b/255)
            # Map cool blues/cyans into deep crimson/scarlet while preserving luminance.
            if 0.48 <= h <= 0.72:
                # blue/cyan -> crimson with a slight hue variation based on original hue
                nh=target_h + (h-0.60)*0.18
                nh%=1.0
                ns=min(1.0, s*1.10)
                rr,gg,bb=colorsys.hsv_to_rgb(nh,ns,v)
                px[x,y]=(int(rr*255),int(gg*255),int(bb*255),a)
            elif 0.72 < h < 0.84:
                nh=(0.97 + (h-0.78)*0.2)%1.0
                rr,gg,bb=colorsys.hsv_to_rgb(nh,min(1,s*1.05),v)
                px[x,y]=(int(rr*255),int(gg*255),int(bb*255),a)
    im.save(dst, optimize=True)

for rel in [
    'Assets.xcassets/SlowthBackground.imageset/SlowthBackground.png',
    'Assets.xcassets/SlowthIntro.imageset/SlowthIntro.png',
    'Assets.xcassets/AppIcon.appiconset/AppIcon-1024.png',
]:
    p=root/rel
    hue_to_red(p,p)

# Design system: deep wine/black + crimson + royal gold.
p=root/'views/DesignSystem.swift'
s=p.read_text()
s=s.replace('// Dark-fantasy palette: moonlit blue, arcane cyan and deep midnight surfaces.', '// Dark-fantasy royal palette: blood crimson, garnet red and deep obsidian surfaces.')
s=s.replace('red: 0.25, green: 0.62, blue: 1.00', 'red: 0.88, green: 0.08, blue: 0.18')
s=s.replace('red: 0.08, green: 0.36, blue: 0.82', 'red: 0.58, green: 0.02, blue: 0.08')
s=s.replace('static let arcaneBlue = Color(red: 0.22, green: 0.55, blue: 1.00)', 'static let arcaneBlue = Color(red: 0.76, green: 0.025, blue: 0.09)')
s=s.replace('static let moonBlue = Color(red: 0.42, green: 0.78, blue: 1.00)', 'static let moonBlue = Color(red: 1.00, green: 0.28, blue: 0.36)')
s=s.replace('static let midnight = Color(red: 0.018, green: 0.028, blue: 0.075)', 'static let midnight = Color(red: 0.045, green: 0.006, blue: 0.012)')
s=s.replace('Color(red: 0.01, green: 0.02, blue: 0.06).opacity(0.62)', 'Color(red: 0.018, green: 0.002, blue: 0.006).opacity(0.72)')
s=s.replace('Color(red: 0.04, green: 0.07, blue: 0.15).opacity(0.92)', 'Color(red: 0.09, green: 0.012, blue: 0.022).opacity(0.94)')
s=s.replace('let count = 78', 'let count = 96')
p.write_text(s)

# Remove activation/deactivation voice only; leave patch behavior untouched.
p=root/'views/PatchProjectsView.swift'
s=p.read_text()
s=s.replace('import AVFoundation\n','')
start=s.find('private enum SlowthVoiceFeedback {')
if start!=-1:
    end=s.find('\nprivate struct PatchActivationControl', start)
    if end==-1: raise SystemExit('voice block end not found')
    s=s[:start]+s[end+1:]
s=s.replace('                    SlowthVoiceFeedback.speak("opción activada")\n','')
s=s.replace('                    SlowthVoiceFeedback.speak("opción desactivada")\n','')
p.write_text(s)

# Key gate / intro: replace blue/ice accents with royal red/gold.
p=root/'App.swift'
s=p.read_text()
s=s.replace('navigation.backgroundColor = UIColor(red: 0.018, green: 0.028, blue: 0.075, alpha: 0.82)', 'navigation.backgroundColor = UIColor(red: 0.045, green: 0.006, blue: 0.012, alpha: 0.90)')
s=s.replace('navigation.shadowColor = UIColor(red: 0.25, green: 0.62, blue: 1.00, alpha: 0.20)', 'navigation.shadowColor = UIColor(red: 0.88, green: 0.08, blue: 0.18, alpha: 0.28)')
s=s.replace('UIColor(red: 0.86, green: 0.94, blue: 1.00, alpha: 1.0)', 'UIColor(red: 1.00, green: 0.90, blue: 0.84, alpha: 1.0)')
s=s.replace('UINavigationBar.appearance().tintColor = UIColor(red: 0.25, green: 0.62, blue: 1.00, alpha: 1.0)', 'UINavigationBar.appearance().tintColor = UIColor(red: 0.92, green: 0.10, blue: 0.20, alpha: 1.0)')
s=s.replace('UITabBar.appearance().backgroundColor = UIColor(red: 0.012, green: 0.018, blue: 0.055, alpha: 0.88)', 'UITabBar.appearance().backgroundColor = UIColor(red: 0.028, green: 0.003, blue: 0.008, alpha: 0.92)')
s=s.replace('UITabBar.appearance().tintColor = UIColor(red: 0.25, green: 0.62, blue: 1.00, alpha: 1.0)', 'UITabBar.appearance().tintColor = UIColor(red: 0.92, green: 0.10, blue: 0.20, alpha: 1.0)')
s=s.replace('UITabBar.appearance().unselectedItemTintColor = UIColor(red: 0.48, green: 0.58, blue: 0.72, alpha: 1.0)', 'UITabBar.appearance().unselectedItemTintColor = UIColor(red: 0.42, green: 0.26, blue: 0.29, alpha: 1.0)')
s=s.replace('    private let blue = Color(red: 0.18, green: 0.56, blue: 1.0)\n    private let ice = Color(red: 0.72, green: 0.91, blue: 1.0)', '    private let crimson = Color(red: 0.92, green: 0.08, blue: 0.16)\n    private let royalGold = Color(red: 0.94, green: 0.67, blue: 0.25)')
# Both key gate and intro use the same old identifiers; after replacing declarations, map usages in each view.
s=s.replace('RadialGradient(\n                colors: [blue.opacity(0.18), AppTheme.midnight.opacity(0.42)]', 'RadialGradient(\n                colors: [crimson.opacity(0.22), AppTheme.midnight.opacity(0.48)]')
s=s.replace('SlowthParticleField(color: blue, animate: !reduceMotion)', 'SlowthParticleField(color: crimson, animate: !reduceMotion)')
s=s.replace('Circle()\n                .stroke(blue.opacity(0.42)', 'Circle()\n                .stroke(crimson.opacity(0.48)')
s=s.replace('colors: [ice, .white, blue]', 'colors: [royalGold, .white, crimson]')
s=s.replace('.shadow(color: blue.opacity(0.9)', '.shadow(color: crimson.opacity(0.95)')
s=s.replace('.foregroundStyle(ice.opacity(0.72))', '.foregroundStyle(royalGold.opacity(0.78))')
s=s.replace('Color.white.opacity(0.055)', 'Color.black.opacity(0.24)')
s=s.replace('error ? Color.red.opacity(0.85) : blue.opacity(0.55)', 'error ? Color.red.opacity(0.95) : crimson.opacity(0.72)')
s=s.replace('.tint(blue)', '.tint(crimson)')
# Intro occurrences.
s=s.replace('SlowthParticleField(color: blue, animate: start && !reduceMotion)', 'SlowthParticleField(color: crimson, animate: start && !reduceMotion)')
s=s.replace('Circle()\n                .stroke(blue.opacity(0.42)', 'Circle()\n                .stroke(crimson.opacity(0.48)')
s=s.replace('colors: [ice, .white, blue]', 'colors: [royalGold, .white, crimson]')
s=s.replace('.shadow(color: blue.opacity(0.95)', '.shadow(color: crimson.opacity(0.95)')
s=s.replace('.foregroundStyle(ice.opacity(0.72))', '.foregroundStyle(royalGold.opacity(0.78))')
s=s.replace('Color(red: 0.01, green: 0.04, blue: 0.12).opacity(0.18)', 'Color(red: 0.18, green: 0.005, blue: 0.012).opacity(0.20)')
s=s.replace('colors: [.clear, blue.opacity(0.75), .clear]', 'colors: [.clear, crimson.opacity(0.82), .clear]')
s=s.replace('Text("DARK • BLUE • SYSTEM")', 'Text("DARK • ROYAL • CRIMSON")')
# Make intro shorter without touching key logic.
s=s.replace('duration: 2.2).repeatForever', 'duration: 1.6).repeatForever')
s=s.replace('deadline: .now() + 1.9', 'deadline: .now() + 1.45')
s=s.replace('deadline: .now() + 0.65', 'deadline: .now() + 0.50')
p.write_text(s)

# One remaining hard-coded blue file icon becomes theme accent.
p=root/'views/FileBrowserView.swift'
s=p.read_text().replace('if entry.isDirectory { return .blue }', 'if entry.isDirectory { return AppTheme.accent }')
p.write_text(s)
