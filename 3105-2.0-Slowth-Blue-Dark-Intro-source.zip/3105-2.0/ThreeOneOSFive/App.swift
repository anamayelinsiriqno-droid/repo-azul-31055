import SwiftUI
import UIKit

@main
struct ThreeOneOSFiveApp: App {
    @StateObject private var appState = AppState()
    @StateObject private var patchDraftCoordinator = PatchDraftCoordinator()
    @StateObject private var fileOperationCoordinator = FileOperationCoordinator()
    @StateObject private var patchStore = PatchProjectStore()
    @StateObject private var repositoryStore = PackageRepositoryStore()
    @AppStorage(AppLanguage.storageKey) private var languageCode = AppLanguage.english.rawValue
    @State private var showOnboarding = OnboardingStore.shouldShow()
    @State private var showSlowthIntro = true
    @State private var showAttribution = false
    @State private var updateOffer: AppUpdateChecker.Offer?
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    init() {
        configureDarkFantasyAppearance()
        setupLogCapture()
        log("app: 3105 launching — iOS \(AppInfo.osVersion) (\(AppInfo.osBuild)) \(AppInfo.machineName)")
    }

    private func configureDarkFantasyAppearance() {
        let navigation = UINavigationBarAppearance()
        navigation.configureWithTransparentBackground()
        navigation.backgroundColor = UIColor(red: 0.018, green: 0.028, blue: 0.075, alpha: 0.82)
        navigation.shadowColor = UIColor(red: 0.25, green: 0.62, blue: 1.00, alpha: 0.20)
        navigation.titleTextAttributes = [
            .foregroundColor: UIColor(red: 0.86, green: 0.94, blue: 1.00, alpha: 1.0)
        ]
        navigation.largeTitleTextAttributes = [
            .foregroundColor: UIColor(red: 0.86, green: 0.94, blue: 1.00, alpha: 1.0)
        ]

        UINavigationBar.appearance().standardAppearance = navigation
        UINavigationBar.appearance().scrollEdgeAppearance = navigation
        UINavigationBar.appearance().compactAppearance = navigation
        UINavigationBar.appearance().tintColor = UIColor(red: 0.25, green: 0.62, blue: 1.00, alpha: 1.0)

        UITabBar.appearance().isTranslucent = true
        UITabBar.appearance().backgroundColor = UIColor(red: 0.012, green: 0.018, blue: 0.055, alpha: 0.88)
        UITabBar.appearance().tintColor = UIColor(red: 0.25, green: 0.62, blue: 1.00, alpha: 1.0)
        UITabBar.appearance().unselectedItemTintColor = UIColor(red: 0.48, green: 0.58, blue: 0.72, alpha: 1.0)

        UITableView.appearance().backgroundColor = .clear
        UITableViewCell.appearance().backgroundColor = .clear
    }

    private var language: AppLanguage {
        AppLanguage(rawValue: languageCode) ?? .english
    }

    private func checkForUpdate() {
        Task {
            guard let offer = await AppUpdateChecker.check() else { return }
            await MainActor.run { updateOffer = offer }
        }
    }

    var body: some Scene {
        WindowGroup {
            ZStack {
                ContentView()
                    .environmentObject(appState)
                    .environmentObject(patchDraftCoordinator)
                    .environmentObject(fileOperationCoordinator)
                    .environmentObject(patchStore)
                    .environmentObject(repositoryStore)
                    .environment(\.appLanguage, language)
                    .environment(\.locale, language.locale)
                    .opacity((showOnboarding || showSlowthIntro) ? 0 : 1)
                    .allowsHitTesting(!showOnboarding && !showSlowthIntro)

                if showOnboarding && !showSlowthIntro {
                    OnboardingView {
                        OnboardingStore.markCompleted()
                        withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.24)) {
                            showOnboarding = false
                        }
                        appState.detectSupport()
                        checkForUpdate()
                    }
                    .environment(\.appLanguage, language)
                    .environment(\.locale, language.locale)
                    .transition(
                        reduceMotion
                            ? .opacity
                            : .opacity.combined(with: .scale(scale: 0.98))
                    )
                    .zIndex(1)
                }

                if showSlowthIntro {
                    SlowthLaunchIntro {
                        withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.55)) {
                            showSlowthIntro = false
                        }
                    }
                    .zIndex(2)
                }
            }
            .displayIdentityAttribution(isPresented: $showAttribution, enabled: !showOnboarding)
            .sheet(isPresented: $showAttribution) {
                DisplayAttributionSheet()
            }
            .alert(item: $updateOffer) { offer in
                Alert(
                    title: Text(language.text("update.title")),
                    message: Text(language.text("update.message", offer.version)),
                    primaryButton: .default(Text(language.text("update.agree"))) {
                        UIApplication.shared.open(offer.url)
                    },
                    secondaryButton: .cancel(Text(language.text("update.dismiss"))) {
                        AppUpdateChecker.dismiss(version: offer.version)
                    }
                )
            }
            .onAppear {
                if !showOnboarding {
                    appState.detectSupport()
                    checkForUpdate()
                }
            }
            .onChange(of: scenePhase) { phase in
                guard phase == .active, !showOnboarding else { return }
                appState.detectSupport()
            }
            .onOpenURL { url in
                patchDraftCoordinator.presentImport(url)
            }
        }
    }
}

class AppState: ObservableObject {
    @Published var exploitStatus: ExploitStatus = .notStarted
    @Published var unsupportedMessage: String?
    @Published var kernelExploitRunning = false

    private var autoRunAttempted = false

    var kernelExploitApplicable: Bool {
        KernelExploit.isApplicable(
            major: AppInfo.versionTuple.major,
            minor: AppInfo.versionTuple.minor,
            patch: AppInfo.versionTuple.patch,
            build: AppInfo.osBuild
        )
    }

    var isSupported: Bool { unsupportedMessage == nil }

    func detectSupport() {
        let v = AppInfo.versionTuple
        let supported = ExploitSupportPolicy.isSupported(
            major: v.major,
            minor: v.minor,
            patch: v.patch,
            build: AppInfo.osBuild
        )
#if targetEnvironment(simulator)
        if ProcessInfo.processInfo.arguments.contains("--simulate-access") {
            exploitStatus = .success(method: "Simulator preview")
        }
#endif

        unsupportedMessage = supported ? nil : "iOS \(AppInfo.osVersion) (\(AppInfo.osBuild))"
        if let unsupportedMessage {
            exploitStatus = .unsupported(unsupportedMessage)
            return
        }

        let applicable = KernelExploit.isApplicable(
            major: v.major,
            minor: v.minor,
            patch: v.patch,
            build: AppInfo.osBuild
        )
        guard applicable else { return }

        refreshKernelExploitStatus()
        maybeAutoRunKernelExploit()
    }

    private func maybeAutoRunKernelExploit() {
        guard !kernelExploitRunning,
              !exploitStatus.isSuccess,
              !exploitStatus.isFailed,
              !autoRunAttempted else { return }
        autoRunAttempted = true
        log("app: starting kernel exploit automatically")
        runKernelExploitIfNeeded()
    }

    private func refreshKernelExploitStatus() {
        guard !kernelExploitRunning else { return }

        // iOS < 26: kernel R/W success persists (no sandbox probe)
        // iOS >= 26: verify full sandbox escape is still active
        if KernelExploit.requiresSandboxEscape {
            if KernelExploit.hasSandboxAccess() {
                if !exploitStatus.isSuccess {
                    exploitStatus = .success(method: "kexploit")
                    log("app: existing sandbox access is still active; skipping kernel exploit")
                }
            } else if exploitStatus.isSuccess {
                exploitStatus = .notStarted
                log("app: sandbox access is no longer active")
            }
        }
    }

    func runKernelExploitIfNeeded() {
        refreshKernelExploitStatus()
        guard !kernelExploitRunning,
              !exploitStatus.isSuccess,
              !exploitStatus.isFailed else { return }
        kernelExploitRunning = true
        exploitStatus = .notStarted
        log("app: running kernel exploit on background...")
        DispatchQueue.global(qos: .userInitiated).async {
            let ok = KernelExploit.run()
            DispatchQueue.main.async {
                self.kernelExploitRunning = false
                if ok {
                    self.exploitStatus = .success(method: "kexploit")
                    if KernelExploit.requiresSandboxEscape {
                        log("app: kernel exploit success — sandbox access verified")
                    } else {
                        log("app: kernel exploit success — kernel access active")
                    }
                } else {
                    self.exploitStatus = .failed(method: "kexploit", code: -1)
                    log("app: kernel exploit failed — relaunch the app before retrying")
                }
            }
        }
    }
}


// MARK: - Slowth Launch Intro

private struct SlowthLaunchIntro: View {
    let onFinished: () -> Void

    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var start = false
    @State private var pulse = false
    @State private var shimmer = false
    @State private var finished = false

    private let blue = Color(red: 0.18, green: 0.56, blue: 1.0)
    private let ice = Color(red: 0.72, green: 0.91, blue: 1.0)

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [
                    Color(red: 0.005, green: 0.012, blue: 0.035),
                    Color(red: 0.012, green: 0.035, blue: 0.09),
                    Color.black
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            RadialGradient(
                colors: [blue.opacity(0.20), .clear],
                center: .center,
                startRadius: 10,
                endRadius: 330
            )
            .scaleEffect(pulse ? 1.12 : 0.82)
            .opacity(start ? 1 : 0)
            .ignoresSafeArea()

            SlowthParticleField(color: blue, animate: start && !reduceMotion)
                .opacity(start ? 1 : 0)

            ForEach(0..<3, id: \.self) { index in
                Circle()
                    .stroke(
                        LinearGradient(
                            colors: [.clear, blue.opacity(0.75), ice.opacity(0.35), .clear],
                            startPoint: .top,
                            endPoint: .bottom
                        ),
                        lineWidth: index == 1 ? 1.6 : 1
                    )
                    .frame(
                        width: CGFloat(190 + index * 95),
                        height: CGFloat(190 + index * 95)
                    )
                    .rotationEffect(.degrees(Double(index) * 28 + (pulse ? 360 : 0)))
                    .opacity(start ? (index == 1 ? 0.72 : 0.34) : 0)
                    .animation(
                        reduceMotion ? nil : .linear(duration: 7 + Double(index) * 2).repeatForever(autoreverses: false),
                        value: pulse
                    )
            }

            VStack(spacing: 16) {
                ZStack {
                    Circle()
                        .fill(blue.opacity(0.08))
                        .frame(width: 142, height: 142)

                    Circle()
                        .stroke(blue.opacity(0.48), lineWidth: 1)
                        .frame(width: 126, height: 126)

                    Circle()
                        .stroke(ice.opacity(0.25), style: StrokeStyle(lineWidth: 1, dash: [3, 7]))
                        .frame(width: 104, height: 104)
                        .rotationEffect(.degrees(shimmer ? 360 : 0))
                        .animation(
                            reduceMotion ? nil : .linear(duration: 9).repeatForever(autoreverses: false),
                            value: shimmer
                        )

                    Image(systemName: "bolt.fill")
                        .font(.system(size: 34, weight: .semibold))
                        .foregroundStyle(ice)
                        .shadow(color: blue.opacity(0.9), radius: 18)
                        .scaleEffect(pulse ? 1.04 : 0.94)
                }
                .scaleEffect(start ? 1 : 0.72)
                .opacity(start ? 1 : 0)

                Text("SLOWTH")
                    .font(.system(size: 38, weight: .black, design: .rounded))
                    .tracking(10)
                    .foregroundStyle(
                        LinearGradient(
                            colors: [ice, blue, Color.white.opacity(0.82)],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .shadow(color: blue.opacity(0.95), radius: shimmer ? 22 : 9)
                    .opacity(start ? 1 : 0)
                    .scaleEffect(start ? 1 : 0.92)

                Text("DARK • BLUE • SYSTEM")
                    .font(.system(size: 10, weight: .medium, design: .monospaced))
                    .tracking(3.2)
                    .foregroundStyle(ice.opacity(0.58))
                    .opacity(start ? 1 : 0)
            }

            VStack {
                Spacer()
                Rectangle()
                    .fill(
                        LinearGradient(
                            colors: [.clear, blue.opacity(0.55), .clear],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .frame(height: 1)
                    .frame(maxWidth: 260)
                    .opacity(shimmer ? 1 : 0.35)
                    .padding(.bottom, 46)
            }
        }
        .onAppear {
            guard !finished else { return }
            if reduceMotion {
                start = true
                pulse = true
                shimmer = true
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.25) {
                    finish()
                }
            } else {
                withAnimation(.easeOut(duration: 0.8)) { start = true }
                pulse = true
                shimmer = true
                DispatchQueue.main.asyncAfter(deadline: .now() + 3.6) {
                    finish()
                }
            }
        }
    }

    private func finish() {
        guard !finished else { return }
        finished = true
        onFinished()
    }
}

private struct SlowthParticleField: View {
    let color: Color
    let animate: Bool

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 30.0, paused: !animate)) { timeline in
            Canvas { context, size in
                let time = timeline.date.timeIntervalSinceReferenceDate
                let count = 54
                for i in 0..<count {
                    let seed = Double(i * 37 + 11)
                    let x = (sin(seed * 0.17) * 0.5 + 0.5) * size.width
                    let baseY = (cos(seed * 0.11) * 0.5 + 0.5) * size.height
                    let rise = (time * (8 + Double(i % 5) * 3)).truncatingRemainder(dividingBy: size.height + 80)
                    let y = (baseY - rise).truncatingRemainder(dividingBy: size.height + 80)
                    let finalY = y < -20 ? y + size.height + 80 : y
                    let radius = CGFloat(0.7 + Double(i % 4) * 0.45)
                    let alpha = 0.12 + 0.13 * (sin(time * 1.6 + seed) * 0.5 + 0.5)
                    context.opacity = alpha
                    context.fill(
                        Path(ellipseIn: CGRect(x: x, y: finalY, width: radius * 2, height: radius * 2)),
                        with: .color(color)
                    )
                }
            }
        }
        .allowsHitTesting(false)
        .ignoresSafeArea()
    }
}
