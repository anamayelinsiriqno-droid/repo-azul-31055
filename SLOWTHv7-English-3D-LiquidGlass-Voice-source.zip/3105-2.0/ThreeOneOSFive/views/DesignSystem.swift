import SwiftUI

enum AppTheme {
    // Dark-fantasy palette: moonlit blue, arcane cyan and deep midnight surfaces.
    static let accent = Color(
        uiColor: UIColor { traits in
            traits.userInterfaceStyle == .dark
                ? UIColor(red: 0.25, green: 0.62, blue: 1.00, alpha: 1.00)
                : UIColor(red: 0.08, green: 0.36, blue: 0.82, alpha: 1.00)
        }
    )
    static let arcaneBlue = Color(red: 0.22, green: 0.55, blue: 1.00)
    static let moonBlue = Color(red: 0.42, green: 0.78, blue: 1.00)
    static let midnight = Color(red: 0.018, green: 0.028, blue: 0.075)
    static let pageBackground = Color(uiColor: .systemBackground)
    static let consoleBackground = Color(uiColor: .secondarySystemBackground)
    static let pageInset: CGFloat = 16
    static let rowIconSize: CGFloat = 17
    static let rowIconFrame: CGFloat = 28
    static let fileRowIconSize: CGFloat = 17
    static let fileRowIconFrame: CGFloat = 30
    static let fileRowHeight: CGFloat = 60
    static let appIconSize: CGFloat = 32
    static let emptyIconSize: CGFloat = 30
    static let selectionIconSize: CGFloat = 18
    static let contentCardCornerRadius: CGFloat = 20
    static let contentCardInset: CGFloat = 16
    static let contentCardPadding: CGFloat = 16
}

struct DarkFantasyBackground: View {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var animate = false
    @State private var depth = false

    var body: some View {
        GeometryReader { proxy in
            ZStack {
                Color.black.ignoresSafeArea()

                // Back layer: slow 3D parallax.
                Image("SlowthBackground")
                    .resizable()
                    .scaledToFill()
                    .scaleEffect(1.10)
                    .offset(
                        x: animate && !reduceMotion ? -10 : 0,
                        y: animate && !reduceMotion ? 7 : 0
                    )
                    .rotation3DEffect(
                        .degrees(depth && !reduceMotion ? 1.8 : -1.2),
                        axis: (x: 1, y: 0, z: 0),
                        perspective: 0.72
                    )
                    .rotation3DEffect(
                        .degrees(depth && !reduceMotion ? -1.4 : 1.0),
                        axis: (x: 0, y: 1, z: 0),
                        perspective: 0.72
                    )
                    .frame(width: proxy.size.width + 32, height: proxy.size.height + 32)
                    .clipped()

                // Front layer creates a subtle depth/energy separation.
                Image("SlowthBackground")
                    .resizable()
                    .scaledToFill()
                    .scaleEffect(1.07)
                    .offset(
                        x: animate && !reduceMotion ? 8 : -5,
                        y: animate && !reduceMotion ? -5 : 4
                    )
                    .opacity(0.20)
                    .blendMode(.screen)
                    .rotation3DEffect(
                        .degrees(depth && !reduceMotion ? -2.2 : 1.4),
                        axis: (x: 0, y: 1, z: 0),
                        perspective: 0.68
                    )
                    .frame(width: proxy.size.width + 32, height: proxy.size.height + 32)
                    .clipped()

                // Moving arcane light adds life while keeping the UI readable.
                RadialGradient(
                    colors: [
                        AppTheme.moonBlue.opacity(animate ? 0.16 : 0.05),
                        AppTheme.arcaneBlue.opacity(animate ? 0.07 : 0.02),
                        Color.clear
                    ],
                    center: UnitPoint(
                        x: animate ? 0.68 : 0.32,
                        y: animate ? 0.28 : 0.62
                    ),
                    startRadius: 8,
                    endRadius: max(proxy.size.width, proxy.size.height) * 0.78
                )
                .blendMode(.screen)

                LinearGradient(
                    colors: [
                        Color.black.opacity(0.48),
                        AppTheme.midnight.opacity(0.26),
                        Color.black.opacity(0.70)
                    ],
                    startPoint: .top,
                    endPoint: .bottom
                )

                SlowthParticleField(
                    color: AppTheme.moonBlue,
                    animate: !reduceMotion
                )
                .opacity(0.24)
            }
            .ignoresSafeArea()
        }
        .onAppear {
            guard !reduceMotion else { return }
            withAnimation(.easeInOut(duration: 8).repeatForever(autoreverses: true)) {
                animate = true
            }
            withAnimation(.linear(duration: 11).repeatForever(autoreverses: true)) {
                depth = true
            }
        }
        .accessibilityHidden(true)
    }
}


struct AppCardBorder: View {
    var body: some View {
        RoundedRectangle(
            cornerRadius: AppTheme.contentCardCornerRadius,
            style: .continuous
        )
        .strokeBorder(
            AppTheme.arcaneBlue.opacity(0.22),
            lineWidth: 0.65
        )
        .accessibilityHidden(true)
    }
}

struct AppRowIcon: View {
    let systemName: String
    var tint: Color = AppTheme.accent
    var symbolSize: CGFloat = AppTheme.rowIconSize
    var frameSize: CGFloat = AppTheme.rowIconFrame

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 7, style: .continuous)
                .fill(tint.opacity(0.12))
            Image(systemName: systemName)
                .font(.system(size: symbolSize, weight: .medium))
                .foregroundStyle(tint)
        }
        .frame(width: frameSize, height: frameSize)
        .accessibilityHidden(true)
    }
}

struct AppSearchField: View {
    @Binding var text: String
    let prompt: String
    let clearLabel: String

    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: "magnifyingglass")
                .font(.system(size: 14, weight: .medium))
                .foregroundStyle(.secondary)
                .accessibilityHidden(true)

            TextField(prompt, text: $text)
                .font(.body)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .submitLabel(.search)

            if !text.isEmpty {
                Button {
                    text = ""
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .font(.system(size: 14, weight: .medium))
                        .foregroundStyle(.tertiary)
                }
                .buttonStyle(.plain)
                .accessibilityLabel(clearLabel)
            }
        }
        .padding(.horizontal, 11)
        .frame(minHeight: 36)
        .background(
            Color(red: 0.04, green: 0.07, blue: 0.15).opacity(0.92),
            in: RoundedRectangle(cornerRadius: 10, style: .continuous)
        )
        .padding(.horizontal, AppTheme.pageInset)
        .padding(.vertical, 8)
        .background(.bar)
    }
}

struct AppLogo: View {
    var size: CGFloat = 44

    var body: some View {
        Group {
            if let icon = UIImage(named: "AppIcon60x60")
                ?? Bundle.main.path(forResource: "AppIcon60x60@2x", ofType: "png").flatMap(UIImage.init(contentsOfFile:))
                ?? UIImage(named: "AppIcon") {
                Image(uiImage: icon)
                    .resizable()
                    .scaledToFill()
            } else {
                Image(systemName: "slider.horizontal.3")
                    .font(.title2.weight(.semibold))
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(AppTheme.accent)
            }
        }
        .frame(width: size, height: size)
        .clipShape(RoundedRectangle(cornerRadius: size * 0.22, style: .continuous))
        .accessibilityHidden(true)
    }
}
