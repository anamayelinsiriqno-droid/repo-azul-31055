import SwiftUI

struct OnboardingView: View {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var key = ""
    @State private var invalidKey = false
    @FocusState private var keyFocused: Bool

    var onComplete: () -> Void

    private let accessKey = "Dark$"

    var body: some View {
        ZStack {
            DarkFantasyBackground()

            ScrollView(showsIndicators: false) {
                VStack(spacing: 0) {
                    Spacer(minLength: 120)

                    ZStack {
                        Circle()
                            .fill(AppTheme.accent.opacity(0.08))
                            .frame(width: 210, height: 210)
                            .overlay {
                                Circle().stroke(AppTheme.accent.opacity(0.45), lineWidth: 1.5)
                            }
                        Circle()
                            .stroke(AppTheme.accent.opacity(0.25), lineWidth: 1)
                            .frame(width: 160, height: 160)
                        Image(systemName: "bolt.fill")
                            .font(.system(size: 58, weight: .bold))
                            .foregroundStyle(AppTheme.accent)
                    }

                    VStack(spacing: 8) {
                        Text("Slowthv7")
                            .font(.system(size: 46, weight: .black, design: .rounded))
                            .foregroundStyle(.white)
                        Text("Slowth patch")
                            .font(.system(size: 24, weight: .bold, design: .rounded))
                            .foregroundStyle(.secondary)
                        Text("Sistema de patches 3105")
                            .font(.subheadline.weight(.medium))
                            .foregroundStyle(.secondary)
                    }
                    .padding(.top, 32)

                    VStack(spacing: 12) {
                        HStack(spacing: 10) {
                            Image(systemName: "key.fill")
                                .foregroundStyle(AppTheme.accent)
                            TextField("Key Dark$", text: $key)
                                .textInputAutocapitalization(.never)
                                .autocorrectionDisabled()
                                .focused($keyFocused)
                                .submitLabel(.done)
                                .onSubmit(validateKey)
                        }
                        .padding(.horizontal, 16)
                        .frame(height: 58)
                        .background(AppTheme.cardBackground, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                        .overlay {
                            RoundedRectangle(cornerRadius: 16, style: .continuous)
                                .stroke(invalidKey ? Color.red : AppTheme.accent.opacity(0.25), lineWidth: 1)
                        }

                        Button(action: validateKey) {
                            Text("ENTRAR")
                                .font(.headline.weight(.black))
                                .frame(maxWidth: .infinity)
                                .frame(height: 58)
                        }
                        .buttonStyle(.plain)
                        .foregroundStyle(.white)
                        .background(AppTheme.accent, in: RoundedRectangle(cornerRadius: 16, style: .continuous))

                        if invalidKey {
                            Text("Key incorrecta")
                                .font(.caption.weight(.semibold))
                                .foregroundStyle(.red)
                        }
                    }
                    .padding(.top, 34)

                    Text("Dark$  •  Español")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.secondary)
                        .padding(.top, 24)

                    Spacer(minLength: 100)
                }
                .padding(.horizontal, 28)
                .frame(maxWidth: 560)
                .frame(maxWidth: .infinity)
            }
        }
        .tint(AppTheme.accent)
        .onAppear { keyFocused = true }
    }

    private func validateKey() {
        guard key == accessKey else {
            invalidKey = true
            return
        }
        invalidKey = false
        keyFocused = false
        if reduceMotion {
            onComplete()
        } else {
            withAnimation(.easeInOut(duration: 0.2)) {
                onComplete()
            }
        }
    }
}
