import UIKit
import SwiftUI

enum AppTheme {
    // Dark-fantasy palette: moonlit blue, arcane cyan and deep midnight surfaces.
    static let accent = Color(
        uiColor: UIColor { traits in
            traits.userInterfaceStyle == .dark
                ? UIColor(red: 0.25, green: 0.62, blue: 1.00, alpha: 1.00)
                : UIColor(red: 0.08, green: 0.36, blue: 0.82, alpha: 1.00)
        }
    )
    static let arcaneBlue = Color(red: 0.22, green: 0.55, blue: 1.00)
    static let moonBlue = Color(red: 0.42, green: 0.78, blue: 1.00)
    static let midnight = Color(red: 0.018, green: 0.028, blue: 0.075)
    static let pageBackground = Color(uiColor: .systemBackground)
    static let consoleBackground = Color(uiColor: .secondarySystemBackground)
    static let pageInset: CGFloat = 16
    static let rowIconSize: CGFloat = 17
    static let rowIconFrame: CGFloat = 28
    static let fileRowIconSize: CGFloat = 17
    static let fileRowIconFrame: CGFloat = 30
    static let fileRowHeight: CGFloat = 60
    static let appIconSize: CGFloat = 32
    static let emptyIconSize: CGFloat = 30
    static let selectionIconSize: CGFloat = 18
    static let contentCardCornerRadius: CGFloat = 20
    static let contentCardInset: CGFloat = 16
    static let contentCardPadding: CGFloat = 16
}

struct DarkFantasyBackground: View {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var animate = false

    var body: some View {
        GeometryReader { proxy in
            ZStack {
                Image("SlowthBackground")
                    .resizable()
                    .scaledToFill()
                    .scaleEffect(animate && !reduceMotion ? 1.035 : 1.0)
                    .frame(width: proxy.size.width, height: proxy.size.height)
                    .clipped()

                LinearGradient(
                    colors: [
                        Color.black.opacity(0.22),
                        Color(red: 0.02, green: 0.02, blue: 0.10).opacity(0.10),
                        Color.black.opacity(0.38)
                    ],
                    startPoint: .top,
                    endPoint: .bottom
                )

                SlowthStarField(color: AppTheme.moonBlue, animate: !reduceMotion)
                    .opacity(0.92)
            }
            .ignoresSafeArea()
        }
        .onAppear {
            guard !reduceMotion else { return }
            withAnimation(.easeInOut(duration: 12).repeatForever(autoreverses: true)) {
                animate = true
            }
        }
        .accessibilityHidden(true)
    }
}

struct SlowthStarField: View {
    let color: Color
    let animate: Bool

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 24.0, paused: !animate)) { timeline in
            Canvas { context, size in
                let time = timeline.date.timeIntervalSinceReferenceDate
                for i in 0..<68 {
                    let seed = Double(i * 97 + 19)
                    let x = (sin(seed * 0.071) * 0.5 + 0.5) * size.width
                    let y = (cos(seed * 0.053) * 0.5 + 0.5) * size.height
                    let twinkle = 0.35 + 0.65 * (sin(time * (1.1 + Double(i % 5) * 0.32) + seed) * 0.5 + 0.5)
                    let radius = CGFloat(0.7 + Double(i % 4) * 0.55)
                    context.opacity = 0.20 + 0.55 * twinkle
                    context.fill(
                        Path(ellipseIn: CGRect(x: x - radius, y: y - radius, width: radius * 2, height: radius * 2)),
                        with: .color(color)
                    )
                    if i % 11 == 0 {
                        let flare = CGFloat(2.5 + 2.5 * twinkle)
                        var path = Path()
                        path.move(to: CGPoint(x: x - flare, y: y))
                        path.addLine(to: CGPoint(x: x + flare, y: y))
                        path.move(to: CGPoint(x: x, y: y - flare))
                        path.addLine(to: CGPoint(x: x, y: y + flare))
                        context.stroke(path, with: .color(color), lineWidth: 0.65)
                    }
                }
            }
        }
        .allowsHitTesting(false)
        .ignoresSafeArea()
    }
}

struct LiquidGlassTabBar: View {
    let sections: [AppSection]
    @Binding var selection: Int
    let language: AppLanguage

    var body: some View {
        HStack(spacing: 6) {
            ForEach(sections) { section in
                Button {
                    withAnimation(.spring(response: 0.28, dampingFraction: 0.78)) {
                        selection = section.rawValue
                    }
                } label: {
                    VStack(spacing: 4) {
                        Image(systemName: section.systemImage)
                            .font(.system(size: 17, weight: .semibold))
                        Text(language.text(section.titleKey))
                            .font(.system(size: 10, weight: .semibold))
                    }
                    .foregroundStyle(section.rawValue == selection ? Color.white : Color.white.opacity(0.58))
                    .frame(maxWidth: .infinity)
                    .frame(height: 50)
                    .background {
                        if section.rawValue == selection {
                            Capsule(style: .continuous)
                                .fill(
                                    LinearGradient(
                                        colors: [
                                            AppTheme.accent.opacity(0.92),
                                            AppTheme.arcaneBlue.opacity(0.55)
                                        ],
                                        startPoint: .topLeading,
                                        endPoint: .bottomTrailing
                                    )
                                )
                                .overlay(Capsule().stroke(Color.white.opacity(0.24), lineWidth: 0.6))
                                .shadow(color: AppTheme.accent.opacity(0.45), radius: 10)
                        }
                    }
                }
                .buttonStyle(.plain)
            }
        }
        .padding(7)
        .background(.ultraThinMaterial, in: Capsule(style: .continuous))
        .overlay(
            Capsule(style: .continuous)
                .stroke(
                    LinearGradient(
                        colors: [Color.white.opacity(0.28), AppTheme.accent.opacity(0.38), Color.white.opacity(0.08)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    ),
                    lineWidth: 0.8
                )
        )
        .shadow(color: .black.opacity(0.42), radius: 18, y: 8)
        .padding(.horizontal, 14)
        .padding(.bottom, 8)
    }
}

struct AppCardBorder: View {
    var body: some View {
        RoundedRectangle(
            cornerRadius: AppTheme.contentCardCornerRadius,
            style: .continuous
        )
        .strokeBorder(
            AppTheme.arcaneBlue.opacity(0.22),
            lineWidth: 0.65
        )
        .accessibilityHidden(true)
    }
}

struct AppRowIcon: View {
    let systemName: String
    var tint: Color = AppTheme.accent
    var symbolSize: CGFloat = AppTheme.rowIconSize
    var frameSize: CGFloat = AppTheme.rowIconFrame

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 7, style: .continuous)
                .fill(tint.opacity(0.12))
            Image(systemName: systemName)
                .font(.system(size: symbolSize, weight: .medium))
                .foregroundStyle(tint)
        }
        .frame(width: frameSize, height: frameSize)
        .accessibilityHidden(true)
    }
}

struct AppSearchField: View {
    @Binding var text: String
    let prompt: String
    let clearLabel: String

    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: "magnifyingglass")
                .font(.system(size: 14, weight: .medium))
                .foregroundStyle(.secondary)
                .accessibilityHidden(true)

            TextField(prompt, text: $text)
                .font(.body)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .submitLabel(.search)

            if !text.isEmpty {
                Button {
                    text = ""
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .font(.system(size: 14, weight: .medium))
                        .foregroundStyle(.tertiary)
                }
                .buttonStyle(.plain)
                .accessibilityLabel(clearLabel)
            }
        }
        .padding(.horizontal, 11)
        .frame(minHeight: 36)
        .background(
            Color(red: 0.04, green: 0.07, blue: 0.15).opacity(0.92),
            in: RoundedRectangle(cornerRadius: 10, style: .continuous)
        )
        .padding(.horizontal, AppTheme.pageInset)
        .padding(.vertical, 8)
        .background(.bar)
    }
}

struct AppLogo: View {
    var size: CGFloat = 44

    var body: some View {
        Group {
            if let icon = UIImage(named: "AppIcon60x60")
                ?? Bundle.main.path(forResource: "AppIcon60x60@2x", ofType: "png").flatMap(UIImage.init(contentsOfFile:))
                ?? UIImage(named: "AppIcon") {
                Image(uiImage: icon)
                    .resizable()
                    .scaledToFill()
            } else {
                Image(systemName: "slider.horizontal.3")
                    .font(.title2.weight(.semibold))
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(AppTheme.accent)
            }
        }
        .frame(width: size, height: size)
        .clipShape(RoundedRectangle(cornerRadius: size * 0.22, style: .continuous))
        .accessibilityHidden(true)
    }
}
