# SLOWTH build notes

The Xcode project is at the repository root:

- `ThreeOneOSFive.xcodeproj`
- shared scheme: `3105`
- app target: `3105`

The repository includes `.github/workflows/build.yml`.

The workflow intentionally does **not** sign the app. It finds the installed Xcode on the GitHub macOS runner, locates the `.xcodeproj` without assuming a folder name, verifies the shared `3105` scheme, builds for a generic iOS device with code signing disabled, and packages the resulting `.app` into an unsigned `.ipa`.

The generated IPA is not installable until it is signed with a certificate and provisioning profile appropriate for the target device/distribution method.


## Repair pass
- Added explicit UIKit import to DesignSystem.swift because it uses UIColor and UIImage.
- GitHub workflow now captures full xcodebuild.log and compiler diagnostics as an artifact.
- Unsigned build remains CODE_SIGNING_ALLOWED=NO.
