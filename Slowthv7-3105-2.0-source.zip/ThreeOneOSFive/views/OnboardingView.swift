import SwiftUI

struct OnboardingView: View {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var key = ""
    @State private var error = false
    var onComplete: () -> Void

    var body: some View {
        ZStack {
            DarkFantasyBackground().ignoresSafeArea()
            VStack(spacing: 24) {
                Spacer()
                ZStack {
                    Circle().fill(AppTheme.red.opacity(0.14)).frame(width: 170, height: 170)
                    Circle().stroke(AppTheme.red.opacity(0.45), lineWidth: 1).frame(width: 170, height: 170)
                    Image(systemName: "bolt.shield.fill")
                        .font(.system(size: 58, weight: .black))
                        .foregroundStyle(AppTheme.red)
                        .shadow(color: AppTheme.red.opacity(0.7), radius: 22)
                }
                Text("Slowthv7")
                    .font(.system(size: 42, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Text("Slowth patch")
                    .font(.headline.weight(.bold))
                    .foregroundStyle(.white.opacity(0.55))
                Text("Sistema de patches 3105")
                    .font(.subheadline)
                    .foregroundStyle(.white.opacity(0.42))

                VStack(spacing: 10) {
                    SecureField("Key Dark$", text: $key)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .padding(.horizontal, 16)
                        .frame(height: 50)
                        .background(.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 15))
                        .foregroundStyle(.white)
                    if error {
                        Text("Key incorrecta")
                            .font(.caption.weight(.semibold))
                            .foregroundStyle(.red)
                    }
                    Button {
                        guard key == "Dark$" else { error = true; return }
                        UserDefaults.standard.set(true, forKey: "slowth.darkkey.valid")
                        onComplete()
                    } label: {
                        Text("ENTRAR")
                            .font(.headline.weight(.black))
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity)
                            .frame(height: 52)
                            .background(AppTheme.red, in: RoundedRectangle(cornerRadius: 15))
                    }
                }
                .padding(.top, 8)
                Spacer()
                Text("Dark$ • Español")
                    .font(.caption.monospaced().weight(.bold))
                    .foregroundStyle(.white.opacity(0.28))
            }
            .padding(.horizontal, 26)
            .padding(.vertical, 24)
        }
    }
}
