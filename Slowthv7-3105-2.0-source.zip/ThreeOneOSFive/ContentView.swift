import SwiftUI
import UIKit
import UniformTypeIdentifiers

struct ContentView: View {
    @EnvironmentObject private var patchStore: PatchProjectStore
    @State private var showImporter = false
    @State private var showLibrary = false
    @State private var showSettings = false
    @State private var showKey = false

    var body: some View {
        NavigationStack {
            ZStack {
                DarkFantasyBackground()
                    .ignoresSafeArea()

                ScrollView(showsIndicators: false) {
                    VStack(spacing: 18) {
                        header
                        heroCard
                        actionGrid
                        installedPatches
                        systemCard
                    }
                    .padding(.horizontal, 18)
                    .padding(.top, 16)
                    .padding(.bottom, 30)
                }
            }
            .navigationBarHidden(true)
            .sheet(isPresented: $showImporter) {
                FileDocumentPicker(
                    allowedContentTypes: [UTType(filenameExtension: "3105") ?? .data, .data],
                    copiesSelectedDocument: true,
                    allowsMultipleSelection: false,
                    onSelection: { result in
                        showImporter = false
                        if case .success(let urls) = result, let url = urls.first {
                            patchStore.importPackage(at: url)
                        }
                    },
                    onCancel: { showImporter = false }
                )
                .ignoresSafeArea()
            }
            .sheet(isPresented: $showLibrary) {
                PatchProjectsView()
            }
            .sheet(isPresented: $showSettings) {
                SlowthSettingsView()
            }
            .sheet(isPresented: $showKey) {
                DarkKeyView()
            }
            .patchStorePresentation(patchStore)
        }
    }

    private var header: some View {
        HStack {
            VStack(alignment: .leading, spacing: 3) {
                Text("Slowthv7")
                    .font(.system(size: 30, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Text("Slowth patch")
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.white.opacity(0.62))
            }
            Spacer()
            HStack(spacing: 10) {
                Circle()
                    .fill(AppTheme.red)
                    .frame(width: 9, height: 9)
                    .shadow(color: AppTheme.red.opacity(0.8), radius: 8)
                Button { showSettings = true } label: {
                    Image(systemName: "gearshape.fill")
                        .font(.system(size: 16, weight: .bold))
                        .foregroundStyle(.white)
                        .frame(width: 40, height: 40)
                        .background(.white.opacity(0.08), in: Circle())
                }
            }
        }
    }

    private var heroCard: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Label("SLOWTH PATCH", systemImage: "bolt.shield.fill")
                    .font(.caption.weight(.black))
                    .foregroundStyle(AppTheme.red)
                Spacer()
                Text("DARK$")
                    .font(.caption2.monospaced().weight(.black))
                    .foregroundStyle(.white.opacity(0.55))
            }

            Text("Panel de parches")
                .font(.system(size: 28, weight: .black, design: .rounded))
                .foregroundStyle(.white)

            Text("Administra tus patches 3105 y aplícalos desde una sola interfaz.")
                .font(.subheadline)
                .foregroundStyle(.white.opacity(0.65))
                .fixedSize(horizontal: false, vertical: true)

            HStack(spacing: 10) {
                Button { showImporter = true } label: {
                    Label("Importar Patch", systemImage: "square.and.arrow.down.fill")
                        .font(.subheadline.weight(.bold))
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity)
                        .frame(height: 48)
                        .background(AppTheme.red, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                }

                Button { showLibrary = true } label: {
                    Image(systemName: "shippingbox.fill")
                        .font(.title3.weight(.bold))
                        .foregroundStyle(.white)
                        .frame(width: 48, height: 48)
                        .background(.white.opacity(0.09), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                }
            }
        }
        .padding(20)
        .background(
            LinearGradient(
                colors: [Color.black.opacity(0.96), AppTheme.deepRed.opacity(0.78), Color.black.opacity(0.98)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            ),
            in: RoundedRectangle(cornerRadius: 24, style: .continuous)
        )
        .overlay(RoundedRectangle(cornerRadius: 24).stroke(AppTheme.red.opacity(0.38), lineWidth: 1))
        .shadow(color: .black.opacity(0.45), radius: 22, y: 12)
    }

    private var actionGrid: some View {
        HStack(spacing: 12) {
            actionCard("Patches", "shippingbox.fill", "\(patchStore.items.count)") { showLibrary = true }
            actionCard("Importar", "arrow.down.doc.fill", "3105") { showImporter = true }
            actionCard("Key", "key.fill", "Dark$") { showKey = true }
        }
    }

    private func actionCard(_ title: String, _ icon: String, _ value: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 10) {
                Image(systemName: icon)
                    .font(.title3.weight(.bold))
                    .foregroundStyle(AppTheme.red)
                Text(value)
                    .font(.headline.weight(.black))
                    .foregroundStyle(.white)
                    .lineLimit(1)
                    .minimumScaleFactor(0.7)
                Text(title)
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.white.opacity(0.52))
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(14)
            .background(.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 18).stroke(.white.opacity(0.08), lineWidth: 1))
        }
        .buttonStyle(.plain)
    }

    private var installedPatches: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Patches incluidos")
                    .font(.headline.weight(.black))
                    .foregroundStyle(.white)
                Spacer()
                Button("Ver todos") { showLibrary = true }
                    .font(.caption.weight(.bold))
                    .foregroundStyle(AppTheme.red)
            }

            if patchStore.items.isEmpty {
                Text("Preparando la biblioteca de patches…")
                    .font(.subheadline)
                    .foregroundStyle(.white.opacity(0.5))
                    .padding(.vertical, 8)
            } else {
                ForEach(Array(patchStore.items.prefix(5))) { item in
                    HStack(spacing: 12) {
                        Image(systemName: item.isLocked ? "lock.fill" : "checkmark.shield.fill")
                            .foregroundStyle(AppTheme.red)
                            .frame(width: 34, height: 34)
                            .background(AppTheme.red.opacity(0.1), in: RoundedRectangle(cornerRadius: 10))
                        VStack(alignment: .leading, spacing: 3) {
                            Text(item.project?.name ?? item.packageURL.deletingPathExtension().lastPathComponent)
                                .font(.subheadline.weight(.bold))
                                .foregroundStyle(.white)
                            Text(item.isLocked ? "Protegido" : "Disponible para activar")
                                .font(.caption)
                                .foregroundStyle(.white.opacity(0.48))
                        }
                        Spacer()
                        Image(systemName: "chevron.right")
                            .font(.caption.weight(.bold))
                            .foregroundStyle(.white.opacity(0.3))
                    }
                    .padding(12)
                    .background(.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 15))
                }
            }
        }
        .padding(16)
        .background(.black.opacity(0.46), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 22).stroke(.white.opacity(0.07), lineWidth: 1))
    }

    private var systemCard: some View {
        HStack(spacing: 12) {
            Image(systemName: "checkmark.circle.fill")
                .foregroundStyle(.green)
                .font(.title3)
            VStack(alignment: .leading, spacing: 2) {
                Text("Sistema listo")
                    .font(.subheadline.weight(.bold))
                    .foregroundStyle(.white)
                Text("Los patches integrados aparecen automáticamente.")
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.5))
            }
            Spacer()
        }
        .padding(15)
        .background(.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 17))
    }
}

struct DarkFantasyBackground: View {
    var body: some View {
        ZStack {
            Color.black
            RadialGradient(colors: [AppTheme.deepRed.opacity(0.52), .clear], center: .topLeading, startRadius: 20, endRadius: 430)
            RadialGradient(colors: [AppTheme.red.opacity(0.22), .clear], center: .bottomTrailing, startRadius: 30, endRadius: 360)
            LinearGradient(colors: [.clear, .black.opacity(0.72)], startPoint: .top, endPoint: .bottom)
        }
    }
}

struct DarkKeyView: View {
    @Environment(\.dismiss) private var dismiss
    @AppStorage("slowth.darkkey.valid") private var valid = false
    @State private var key = ""
    @State private var message = ""

    var body: some View {
        NavigationStack {
            ZStack {
                DarkFantasyBackground().ignoresSafeArea()
                VStack(spacing: 18) {
                    Image(systemName: "key.fill")
                        .font(.system(size: 38, weight: .bold))
                        .foregroundStyle(AppTheme.red)
                    Text("Sistema Dark$")
                        .font(.title2.weight(.black))
                        .foregroundStyle(.white)
                    Text("Introduce tu key para habilitar el panel.")
                        .foregroundStyle(.white.opacity(0.55))
                        .multilineTextAlignment(.center)
                    SecureField("Key", text: $key)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .padding(14)
                        .background(.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 14))
                        .foregroundStyle(.white)
                    Button("Activar Dark$") {
                        if key == "Dark$" {
                            valid = true
                            message = "Key activada correctamente."
                        } else {
                            message = "Key incorrecta."
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(AppTheme.red)
                    if valid { Text("✓ Dark$ activo").foregroundStyle(.green) }
                    if !message.isEmpty { Text(message).font(.caption).foregroundStyle(.white.opacity(0.7)) }
                    Spacer()
                }
                .padding(24)
            }
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Cerrar") { dismiss() }.foregroundStyle(.white) } }
        }
    }
}

struct SlowthSettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @AppStorage(FeatureVisibility.cleanerStorageKey) private var cleanerEnabled = true
    @AppStorage(FeatureVisibility.developerModeStorageKey) private var developerModeEnabled = false

    var body: some View {
        NavigationStack {
            Form {
                Section("Slowthv7") {
                    LabeledContent("Versión", value: Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "2.0")
                    LabeledContent("Idioma", value: "Español")
                }
                Section("Opciones") {
                    Toggle("Limpiador", isOn: $cleanerEnabled)
                    Toggle("Modo desarrollador", isOn: $developerModeEnabled)
                }
            }
            .navigationTitle("Ajustes")
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Listo") { dismiss() } } }
        }
    }
}
