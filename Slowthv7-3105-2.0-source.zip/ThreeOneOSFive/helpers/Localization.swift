import SwiftUI

enum AppLanguage: String, CaseIterable, Identifiable {
    static let storageKey = "appLanguage"
    case spanish = "es"

    var id: String { rawValue }
    var locale: Locale { Locale(identifier: rawValue) }
    var displayName: String { "Español" }

    private static let spanishText: [String: String] = [
        "common.cancel":"Cancelar","common.clear":"Limpiar","common.delete":"Eliminar","common.ok":"Aceptar","common.done":"Listo","common.device":"Dispositivo","common.version":"Versión %@",
        "tab.installed":"Patches","tab.wallpapers":"Fondos","tab.cleaner":"Limpiador",
        "installed.search":"Buscar patch…","installed.empty_title":"No hay patches","installed.empty_message":"Importa un patch 3105 para comenzar.","installed.loading":"Cargando patches…",
        "patch.title":"Patches","patch.add":"Añadir patch","patch.import":"Importar Patch","patch.new":"Nuevo patch","patch.information":"Información","patch.author":"Autor","patch.by_author":"Por %@","patch.privacy":"Privacidad","patch.private":"Privado","patch.private_received":"Patch privado recibido","patch.private_hidden_title":"Contenido protegido","patch.private_hidden_message":"Este patch no permite ver su contenido.","patch.locked_project":"Patch protegido","patch.password":"Contraseña","patch.password_protected":"Protegido","patch.password_once_message":"Introduce la contraseña para desbloquearlo.","patch.password_repo_contact":"Contacta con %@ para obtener la contraseña.","patch.tap_to_unlock":"Toca para desbloquear","patch.unlock":"Desbloquear","patch.edit":"Editar","patch.edit_rule_hint":"Edita las reglas del patch.","patch.files":"Archivos","patch.folders":"Carpetas","patch.rules":"Reglas","patch.workspace":"Espacio de trabajo","patch.workspace_detail_footer":"Contenido del espacio de trabajo.","patch.open_workspace":"Abrir espacio de trabajo","patch.apply":"Activar Patch","patch.apply_confirm_title":"Activar patch","patch.apply_confirm_message":"¿Quieres activar este patch?","patch.apply_footer":"El patch se aplicará al destino configurado.","patch.reset":"Restablecer","patch.reset_confirm_title":"Restablecer patch","patch.reset_confirm_message":"Se restaurará el estado original.","patch.restore":"Restaurar","patch.restore_confirm_title":"Restaurar","patch.restore_confirm_message":"¿Quieres restaurar los archivos modificados?","patch.restore_changed_action":"Restaurar cambios","patch.restore_changed_title":"Cambios detectados","patch.restore_changed_message":"Hay archivos que cambiaron desde la aplicación.","patch.restore_changed_private_message":"El patch privado tiene cambios pendientes.","patch.legacy_footer":"Patch heredado.","patch.search_empty":"Sin resultados","patch.search_empty_message":"No se encontró ningún patch.",
        "repository.utilities":"Utilidades","repository.cleaner_subtitle":"Limpia archivos temporales.","repository.source":"Origen",
        "wallpaper.import":"Importar fondo","wallpaper.delete_title":"Eliminar fondo","wallpaper.delete_message":"¿Quieres eliminar este fondo?","wallpaper.error.unknown":"Error desconocido.","wallpaper.import_done_message":"Se importaron %@ fondos.","wallpaper.package_summary":"Paquete de fondo",
        "settings.title":"Ajustes","settings.language":"Idioma","settings.credits":"Créditos","settings.current_version":"Versión actual","settings.developer_mode":"Modo desarrollador","settings.developer_mode_footer":"Opciones avanzadas.","settings.ios_version":"Versión de iOS","settings.social_media":"Redes sociales","settings.verified_versions":"Versiones verificadas","settings.supported_versions_footer":"Compatibilidad del sistema.","dashboard.features":"Opciones","dashboard.hardware_model":"Modelo","social.github_role":"Código fuente","social.iosvn_role":"Comunidad","credit.yangjiii":"Proyecto original","credit.filzaslop":"Herramienta relacionada","credit.pocket_poster":"Herramienta relacionada","credit.sandbox_escape":"Sandbox","credit.forcequit":"Sistema","settings.developer_beta_build":"Beta %@ • %@","settings.developer_public_beta_build":"Beta %@ • pública %@ • %@","wallpaper.reset":"Restablecer fondos","wallpaper.reset_settings_footer":"Opciones de fondos.",
        "accessibility.open_profile":"Abrir perfil %@"
    ]

    func text(_ key: String) -> String { Self.spanishText[key] ?? key }
    func text(_ key: String, _ arguments: CVarArg...) -> String {
        String(format: text(key), locale: locale, arguments: arguments)
    }
}

private struct AppLanguageEnvironmentKey: EnvironmentKey { static let defaultValue = AppLanguage.spanish }
extension EnvironmentValues {
    var appLanguage: AppLanguage { get { self[AppLanguageEnvironmentKey.self] } set { self[AppLanguageEnvironmentKey.self] = newValue } }
}

extension ExploitStatus {
    func displayText(language: AppLanguage) -> String {
        switch self {
        case .notStarted: return "No iniciado"
        case .success(let method): return "Correcto • \(method)"
        case .failed(let method, let code): return "Falló • \(method) (\(code))"
        case .unsupported(let message): return "No compatible • \(message)"
        }
    }
}
