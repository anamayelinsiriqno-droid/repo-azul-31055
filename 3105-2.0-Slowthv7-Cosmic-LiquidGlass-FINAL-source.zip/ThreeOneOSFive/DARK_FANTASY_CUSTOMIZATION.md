# Dark Fantasy UI customization

Applied to the SwiftUI source:

- Deep midnight/blue application palette.
- Arcane blue accent and moon-blue highlights.
- Animated atmospheric background with slow drifting light/mist.
- Dark navigation and tab-bar appearance.
- Clear blue selection state in the iPad/sidebar layout.
- Blue-tinted content-card borders.
- Dark blue search-field surface.
- Global dark appearance for the redesigned interface.
- Animations automatically stop when Reduce Motion is enabled.

Files changed:
- `ThreeOneOSFive/App.swift`
- `ThreeOneOSFive/ContentView.swift`
- `ThreeOneOSFive/views/DesignSystem.swift`

The included IPA was not binary-patched because an iOS executable must be rebuilt with the iOS SDK and then signed for these SwiftUI source changes to actually exist in the executable.
