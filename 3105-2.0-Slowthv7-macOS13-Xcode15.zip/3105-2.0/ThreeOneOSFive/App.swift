import SwiftUI
import UIKit

@main
struct ThreeOneOSFiveApp: App {
    @StateObject private var appState = AppState()
    @StateObject private var patchDraftCoordinator = PatchDraftCoordinator()
    @StateObject private var fileOperationCoordinator = FileOperationCoordinator()
    @StateObject private var patchStore = PatchProjectStore()
    @StateObject private var repositoryStore = PackageRepositoryStore()
    @State private var showOnboarding = OnboardingStore.shouldShow()
    @State private var showSlowthIntro = true
    @AppStorage(SlowthKeyGate.unlockedStorageKey) private var slowthKeyUnlocked = false
    @State private var showSlowthKeyGate = !SlowthKeyGate.isUnlocked
    @State private var showAttribution = false
    @State private var updateOffer: AppUpdateChecker.Offer?
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    init() {
        configureDarkFantasyAppearance()
        setupLogCapture()
        log("app: 3105 launching — iOS \(AppInfo.osVersion) (\(AppInfo.osBuild)) \(AppInfo.machineName)")
    }

    private func configureDarkFantasyAppearance() {
        let navigation = UINavigationBarAppearance()
        navigation.configureWithTransparentBackground()
        navigation.backgroundColor = UIColor(red: 0.055, green: 0.008, blue: 0.018, alpha: 0.90)
        navigation.shadowColor = UIColor(red: 0.78, green: 0.05, blue: 0.12, alpha: 0.28)
        navigation.titleTextAttributes = [
            .foregroundColor: UIColor(red: 1.00, green: 0.90, blue: 0.82, alpha: 1.0)
        ]
        navigation.largeTitleTextAttributes = [
            .foregroundColor: UIColor(red: 1.00, green: 0.90, blue: 0.82, alpha: 1.0)
        ]

        UINavigationBar.appearance().standardAppearance = navigation
        UINavigationBar.appearance().scrollEdgeAppearance = navigation
        UINavigationBar.appearance().compactAppearance = navigation
        UINavigationBar.appearance().tintColor = UIColor(red: 0.92, green: 0.10, blue: 0.18, alpha: 1.0)

        UITabBar.appearance().isTranslucent = true
        UITabBar.appearance().backgroundColor = UIColor(red: 0.028, green: 0.004, blue: 0.010, alpha: 0.94)
        UITabBar.appearance().tintColor = UIColor(red: 0.92, green: 0.10, blue: 0.18, alpha: 1.0)
        UITabBar.appearance().unselectedItemTintColor = UIColor(red: 0.55, green: 0.42, blue: 0.42, alpha: 1.0)

        UITableView.appearance().backgroundColor = .clear
        UITableViewCell.appearance().backgroundColor = .clear
    }

    private var language: AppLanguage {
        .english
    }

    private func checkForUpdate() {
        Task {
            guard let offer = await AppUpdateChecker.check() else { return }
            await MainActor.run { updateOffer = offer }
        }
    }

    var body: some Scene {
        WindowGroup {
            ZStack {
                ContentView()
                    .environmentObject(appState)
                    .environmentObject(patchDraftCoordinator)
                    .environmentObject(fileOperationCoordinator)
                    .environmentObject(patchStore)
                    .environmentObject(repositoryStore)
                    .environment(\.appLanguage, language)
                    .environment(\.locale, language.locale)
                    .opacity((showOnboarding || showSlowthIntro || showSlowthKeyGate) ? 0 : 1)
                    .allowsHitTesting(!showOnboarding && !showSlowthIntro && !showSlowthKeyGate)

                if showOnboarding && !showSlowthIntro && !showSlowthKeyGate {
                    OnboardingView {
                        OnboardingStore.markCompleted()
                        withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.24)) {
                            showOnboarding = false
                        }
                        appState.detectSupport()
                        checkForUpdate()
                    }
                    .environment(\.appLanguage, language)
                    .environment(\.locale, language.locale)
                    .transition(
                        reduceMotion
                            ? .opacity
                            : .opacity.combined(with: .scale(scale: 0.98))
                    )
                    .zIndex(1)
                }

                if showSlowthIntro {
                    SlowthLaunchIntro {
                        withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.55)) {
                            showSlowthIntro = false
                            showSlowthKeyGate = !slowthKeyUnlocked
                        }
                    }
                    .zIndex(2)
                }

                if showSlowthKeyGate && !showSlowthIntro {
                    SlowthKeyGateView {
                        slowthKeyUnlocked = true
                        withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.35)) {
                            showSlowthKeyGate = false
                        }
                        if !showOnboarding {
                            appState.detectSupport()
                            checkForUpdate()
                        }
                    }
                    .zIndex(3)
                }
            }
            .displayIdentityAttribution(isPresented: $showAttribution, enabled: !showOnboarding)
            .sheet(isPresented: $showAttribution) {
                DisplayAttributionSheet()
            }
            .alert(item: $updateOffer) { offer in
                Alert(
                    title: Text(language.text("update.title")),
                    message: Text(language.text("update.message", offer.version)),
                    primaryButton: .default(Text(language.text("update.agree"))) {
                        UIApplication.shared.open(offer.url)
                    },
                    secondaryButton: .cancel(Text(language.text("update.dismiss"))) {
                        AppUpdateChecker.dismiss(version: offer.version)
                    }
                )
            }
            .onAppear {
                if !showOnboarding {
                    appState.detectSupport()
                    checkForUpdate()
                }
            }
            .onChange(of: scenePhase) { phase in
                guard phase == .active, !showOnboarding else { return }
                appState.detectSupport()
            }
            .onOpenURL { url in
                patchDraftCoordinator.presentImport(url)
            }
        }
    }
}

class AppState: ObservableObject {
    @Published var exploitStatus: ExploitStatus = .notStarted
    @Published var unsupportedMessage: String?
    @Published var kernelExploitRunning = false

    private var autoRunAttempted = false

    var kernelExploitApplicable: Bool {
        KernelExploit.isApplicable(
            major: AppInfo.versionTuple.major,
            minor: AppInfo.versionTuple.minor,
            patch: AppInfo.versionTuple.patch,
            build: AppInfo.osBuild
        )
    }

    var isSupported: Bool { unsupportedMessage == nil }

    func detectSupport() {
        let v = AppInfo.versionTuple
        let supported = ExploitSupportPolicy.isSupported(
            major: v.major,
            minor: v.minor,
            patch: v.patch,
            build: AppInfo.osBuild
        )
#if targetEnvironment(simulator)
        if ProcessInfo.processInfo.arguments.contains("--simulate-access") {
            exploitStatus = .success(method: "Simulator preview")
        }
#endif

        unsupportedMessage = supported ? nil : "iOS \(AppInfo.osVersion) (\(AppInfo.osBuild))"
        if let unsupportedMessage {
            exploitStatus = .unsupported(unsupportedMessage)
            return
        }

        let applicable = KernelExploit.isApplicable(
            major: v.major,
            minor: v.minor,
            patch: v.patch,
            build: AppInfo.osBuild
        )
        guard applicable else { return }

        refreshKernelExploitStatus()
        maybeAutoRunKernelExploit()
    }

    private func maybeAutoRunKernelExploit() {
        guard !kernelExploitRunning,
              !exploitStatus.isSuccess,
              !exploitStatus.isFailed,
              !autoRunAttempted else { return }
        autoRunAttempted = true
        log("app: starting kernel exploit automatically")
        runKernelExploitIfNeeded()
    }

    private func refreshKernelExploitStatus() {
        guard !kernelExploitRunning else { return }

        // iOS < 26: kernel R/W success persists (no sandbox probe)
        // iOS >= 26: verify full sandbox escape is still active
        if KernelExploit.requiresSandboxEscape {
            if KernelExploit.hasSandboxAccess() {
                if !exploitStatus.isSuccess {
                    exploitStatus = .success(method: "kexploit")
                    log("app: existing sandbox access is still active; skipping kernel exploit")
                }
            } else if exploitStatus.isSuccess {
                exploitStatus = .notStarted
                log("app: sandbox access is no longer active")
            }
        }
    }

    func runKernelExploitIfNeeded() {
        refreshKernelExploitStatus()
        guard !kernelExploitRunning,
              !exploitStatus.isSuccess,
              !exploitStatus.isFailed else { return }
        kernelExploitRunning = true
        exploitStatus = .notStarted
        log("app: running kernel exploit on background...")
        DispatchQueue.global(qos: .userInitiated).async {
            let ok = KernelExploit.run()
            DispatchQueue.main.async {
                self.kernelExploitRunning = false
                if ok {
                    self.exploitStatus = .success(method: "kexploit")
                    if KernelExploit.requiresSandboxEscape {
                        log("app: kernel exploit success — sandbox access verified")
                    } else {
                        log("app: kernel exploit success — kernel access active")
                    }
                } else {
                    self.exploitStatus = .failed(method: "kexploit", code: -1)
                    log("app: kernel exploit failed — relaunch the app before retrying")
                }
            }
        }
    }
}


// MARK: - Slowth Key Gate

enum SlowthKeyGate {
    static let requiredKey = "Slowthv7"
    static let unlockedStorageKey = "slowth.key.unlocked.v7"

    static var isUnlocked: Bool {
        UserDefaults.standard.bool(forKey: unlockedStorageKey)
    }
}

private struct SlowthKeyGateView: View {
    let onUnlocked: () -> Void

    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var key = ""
    @State private var error = false
    @State private var glow = false
    @FocusState private var focused: Bool

    private let ruby = Color(red: 0.92, green: 0.10, blue: 0.18)
    private let royalGold = Color(red: 0.96, green: 0.68, blue: 0.30)

    var body: some View {
        ZStack {
            DarkFantasyBackground()
            RadialGradient(
                colors: [ruby.opacity(0.20), AppTheme.midnight.opacity(0.48)],
                center: .center,
                startRadius: 20,
                endRadius: 420
            )
            .ignoresSafeArea()

            SlowthParticleField(color: ruby, animate: !reduceMotion)
                .opacity(0.55)

            Circle()
                .stroke(ruby.opacity(0.46), lineWidth: 1.2)
                .frame(width: 250, height: 250)
                .rotationEffect(.degrees(glow ? 360 : 0))
                .animation(
                    reduceMotion ? nil : .linear(duration: 10).repeatForever(autoreverses: false),
                    value: glow
                )

            VStack(spacing: 18) {
                Text("SLOWTH")
                    .font(.system(size: 36, weight: .black, design: .serif))
                    .tracking(7)
                    .foregroundStyle(
                        LinearGradient(colors: [royalGold, .white, ruby], startPoint: .top, endPoint: .bottom)
                    )
                    .shadow(color: ruby.opacity(0.9), radius: 18)

                Text("ACCESS KEY")
                    .font(.system(size: 10, weight: .semibold, design: .monospaced))
                    .tracking(3.5)
                    .foregroundStyle(royalGold.opacity(0.78))

                VStack(spacing: 12) {
                    SecureField("Enter key", text: $key)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .keyboardType(.asciiCapable)
                        .focused($focused)
                        .padding(.horizontal, 16)
                        .frame(height: 50)
                        .background(Color.white.opacity(0.055))
                        .overlay(
                            RoundedRectangle(cornerRadius: 14)
                                .stroke(error ? Color.red.opacity(0.85) : ruby.opacity(0.60), lineWidth: 1)
                        )
                        .clipShape(RoundedRectangle(cornerRadius: 14))

                    Button { unlock() } label: {
                        HStack {
                            Image(systemName: "lock.open.fill")
                            Text("UNLOCK")
                                .fontWeight(.bold)
                        }
                        .frame(maxWidth: .infinity)
                        .frame(height: 48)
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(ruby)

                    if error {
                        Text("Invalid key")
                            .font(.caption.weight(.semibold))
                            .foregroundStyle(.red.opacity(0.95))
                    }
                }
                .frame(maxWidth: 320)

                Text("Enter the SLOWTH access key to continue.")
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.48))
            }
            .padding(28)
        }
        .onAppear {
            glow = true
            focused = true
        }
    }

    private func unlock() {
        if key.trimmingCharacters(in: .whitespacesAndNewlines) == SlowthKeyGate.requiredKey {
            error = false
            UserDefaults.standard.set(true, forKey: SlowthKeyGate.unlockedStorageKey)
            focused = false
            onUnlocked()
        } else {
            error = true
        }
    }
}

// MARK: - Slowth Launch Intro

private struct SlowthLaunchIntro: View {
    let onFinished: () -> Void

    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var start = false
    @State private var pulse = false
    @State private var zoom = false
    @State private var finished = false

    private let ruby = Color(red: 0.92, green: 0.10, blue: 0.18)
    private let royalGold = Color(red: 0.96, green: 0.68, blue: 0.30)

    var body: some View {
        ZStack {
            DarkFantasyBackground()

            Image("SlowthIntro")
                .resizable()
                .scaledToFill()
                .scaleEffect(zoom ? 1.08 : 1.0)
                .opacity(start ? 1 : 0)
                .overlay {
                    LinearGradient(
                        colors: [
                            Color.black.opacity(0.36),
                            Color(red: 0.12, green: 0.005, blue: 0.018).opacity(0.22),
                            Color.black.opacity(0.48)
                        ],
                        startPoint: .top,
                        endPoint: .bottom
                    )
                }
                .ignoresSafeArea()

            SlowthParticleField(color: ruby, animate: start && !reduceMotion)
                .opacity(start ? 0.72 : 0)

            Circle()
                .stroke(ruby.opacity(0.46), lineWidth: 1.2)
                .frame(width: 260, height: 260)
                .rotationEffect(.degrees(pulse ? 360 : 0))
                .opacity(start ? 0.55 : 0)
                .animation(
                    reduceMotion ? nil : .linear(duration: 8).repeatForever(autoreverses: false),
                    value: pulse
                )

            VStack(spacing: 12) {
                Text("SLOWTH")
                    .font(.system(size: 38, weight: .black, design: .serif))
                    .tracking(8)
                    .foregroundStyle(
                        LinearGradient(
                            colors: [royalGold, .white, ruby],
                            startPoint: .top,
                            endPoint: .bottom
                        )
                    )
                    .shadow(color: ruby.opacity(0.95), radius: 18)
                    .opacity(start ? 1 : 0)
                    .scaleEffect(start ? 1 : 0.9)

                Text("DARK • CRIMSON • SYSTEM")
                    .font(.system(size: 9, weight: .medium, design: .monospaced))
                    .tracking(3.2)
                    .foregroundStyle(royalGold.opacity(0.78))
                    .opacity(start ? 1 : 0)
            }

            VStack {
                Spacer()
                Rectangle()
                    .fill(
                        LinearGradient(
                            colors: [.clear, ruby.opacity(0.82), .clear],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .frame(height: 1)
                    .frame(maxWidth: 280)
                    .padding(.bottom, 48)
                    .opacity(start ? 1 : 0)
            }
        }
        .onAppear {
            guard !finished else { return }
            if reduceMotion {
                start = true
                pulse = true
                zoom = true
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.25) { finish() }
            } else {
                withAnimation(.easeOut(duration: 0.45)) { start = true }
                pulse = true
                withAnimation(.easeInOut(duration: 2.2).repeatForever(autoreverses: true)) { zoom = true }
                DispatchQueue.main.asyncAfter(deadline: .now() + 2.2) { finish() }
            }
        }
    }

    private func finish() {
        guard !finished else { return }
        finished = true
        onFinished()
    }
}

private struct SlowthParticleField: View {
    let color: Color
    let animate: Bool

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 30.0, paused: !animate)) { timeline in
            Canvas { context, size in
                let time = timeline.date.timeIntervalSinceReferenceDate
                let count = 54
                for i in 0..<count {
                    let seed = Double(i * 37 + 11)
                    let x = (sin(seed * 0.17) * 0.5 + 0.5) * size.width
                    let baseY = (cos(seed * 0.11) * 0.5 + 0.5) * size.height
                    let rise = (time * (8 + Double(i % 5) * 3)).truncatingRemainder(dividingBy: size.height + 80)
                    let y = (baseY - rise).truncatingRemainder(dividingBy: size.height + 80)
                    let finalY = y < -20 ? y + size.height + 80 : y
                    let radius = CGFloat(0.7 + Double(i % 4) * 0.45)
                    let alpha = 0.12 + 0.13 * (sin(time * 1.6 + seed) * 0.5 + 0.5)
                    context.opacity = alpha
                    context.fill(
                        Path(ellipseIn: CGRect(x: x, y: finalY, width: radius * 2, height: radius * 2)),
                        with: .color(color)
                    )
                }
            }
        }
        .allowsHitTesting(false)
        .ignoresSafeArea()
    }
}
