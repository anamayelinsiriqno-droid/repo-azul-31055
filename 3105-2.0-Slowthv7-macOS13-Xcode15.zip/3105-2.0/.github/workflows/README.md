This workflow intentionally runs on macos-13 and selects the newest Xcode 15.x installed on that runner.
It builds target 3105 unsigned and packages the resulting .app as an unsigned IPA.
