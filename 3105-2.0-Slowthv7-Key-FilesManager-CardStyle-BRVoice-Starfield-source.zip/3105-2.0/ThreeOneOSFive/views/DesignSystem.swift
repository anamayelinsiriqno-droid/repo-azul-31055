import SwiftUI

enum AppTheme {
    // Dark-fantasy palette: moonlit blue, arcane cyan and deep midnight surfaces.
    static let accent = Color(
        uiColor: UIColor { traits in
            traits.userInterfaceStyle == .dark
                ? UIColor(red: 0.25, green: 0.62, blue: 1.00, alpha: 1.00)
                : UIColor(red: 0.08, green: 0.36, blue: 0.82, alpha: 1.00)
        }
    )
    static let arcaneBlue = Color(red: 0.22, green: 0.55, blue: 1.00)
    static let moonBlue = Color(red: 0.42, green: 0.78, blue: 1.00)
    static let midnight = Color(red: 0.018, green: 0.028, blue: 0.075)
    static let pageBackground = Color(uiColor: .systemBackground)
    static let consoleBackground = Color(uiColor: .secondarySystemBackground)
    static let pageInset: CGFloat = 16
    static let rowIconSize: CGFloat = 17
    static let rowIconFrame: CGFloat = 28
    static let fileRowIconSize: CGFloat = 17
    static let fileRowIconFrame: CGFloat = 30
    static let fileRowHeight: CGFloat = 60
    static let appIconSize: CGFloat = 32
    static let emptyIconSize: CGFloat = 30
    static let selectionIconSize: CGFloat = 18
    static let contentCardCornerRadius: CGFloat = 20
    static let contentCardInset: CGFloat = 16
    static let contentCardPadding: CGFloat = 16
}

struct DarkFantasyBackground: View {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var animate = false

    var body: some View {
        GeometryReader { proxy in
            ZStack {
                Image("SlowthBackground")
                    .resizable()
                    .scaledToFill()
                    .scaleEffect(animate && !reduceMotion ? 1.045 : 1.0)
                    .frame(width: proxy.size.width, height: proxy.size.height)
                    .clipped()

                LinearGradient(
                    colors: [
                        AppTheme.midnight.opacity(0.48),
                        AppTheme.arcaneBlue.opacity(0.08),
                        Color(red: 0.01, green: 0.02, blue: 0.06).opacity(0.62)
                    ],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )

                SlowthStarField(animate: !reduceMotion)
                    .opacity(0.92)

                RadialGradient(
                    colors: [
                        AppTheme.arcaneBlue.opacity(animate ? 0.12 : 0.05),
                        .clear
                    ],
                    center: animate ? .topTrailing : .topLeading,
                    startRadius: 10,
                    endRadius: max(proxy.size.width, proxy.size.height) * 0.72
                )
                .blendMode(.screen)
            }
            .ignoresSafeArea()
        }
        .onAppear {
            guard !reduceMotion else { return }
            withAnimation(.easeInOut(duration: 10).repeatForever(autoreverses: true)) {
                animate = true
            }
        }
        .accessibilityHidden(true)
    }
}

struct SlowthStarField: View {
    let animate: Bool

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 30.0, paused: !animate)) { timeline in
            Canvas { context, size in
                let time = timeline.date.timeIntervalSinceReferenceDate
                let count = 78

                for index in 0..<count {
                    let seed = Double(index * 97 + 17)
                    let baseX = (sin(seed * 0.731) * 0.5 + 0.5) * size.width
                    let baseY = (cos(seed * 0.417) * 0.5 + 0.5) * size.height
                    let driftX = sin(time * (0.035 + Double(index % 4) * 0.006) + seed) * 12
                    let driftY = cos(time * (0.028 + Double(index % 5) * 0.005) + seed * 0.7) * 18
                    let x = baseX + driftX
                    let y = baseY + driftY
                    let radius = CGFloat(0.45 + Double(index % 4) * 0.42)
                    let twinkle = 0.28 + 0.52 * (sin(time * (0.9 + Double(index % 6) * 0.13) + seed) * 0.5 + 0.5)

                    context.opacity = twinkle
                    context.fill(
                        Path(ellipseIn: CGRect(
                            x: x,
                            y: y,
                            width: radius * 2,
                            height: radius * 2
                        )),
                        with: .color(AppTheme.moonBlue)
                    )

                    if index % 13 == 0 {
                        context.opacity = twinkle * 0.35
                        let glowSize = radius * 7
                        context.fill(
                            Path(ellipseIn: CGRect(
                                x: x - glowSize / 2,
                                y: y - glowSize / 2,
                                width: glowSize,
                                height: glowSize
                            )),
                            with: .color(AppTheme.arcaneBlue)
                        )
                    }
                }
            }
        }
        .allowsHitTesting(false)
        .ignoresSafeArea()
        .accessibilityHidden(true)
    }
}

struct AppCardBorder: View {
    var body: some View {
        RoundedRectangle(
            cornerRadius: AppTheme.contentCardCornerRadius,
            style: .continuous
        )
        .strokeBorder(
            AppTheme.arcaneBlue.opacity(0.22),
            lineWidth: 0.65
        )
        .accessibilityHidden(true)
    }
}

struct AppRowIcon: View {
    let systemName: String
    var tint: Color = AppTheme.accent
    var symbolSize: CGFloat = AppTheme.rowIconSize
    var frameSize: CGFloat = AppTheme.rowIconFrame

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 7, style: .continuous)
                .fill(tint.opacity(0.12))
            Image(systemName: systemName)
                .font(.system(size: symbolSize, weight: .medium))
                .foregroundStyle(tint)
        }
        .frame(width: frameSize, height: frameSize)
        .accessibilityHidden(true)
    }
}

struct AppSearchField: View {
    @Binding var text: String
    let prompt: String
    let clearLabel: String

    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: "magnifyingglass")
                .font(.system(size: 14, weight: .medium))
                .foregroundStyle(.secondary)
                .accessibilityHidden(true)

            TextField(prompt, text: $text)
                .font(.body)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .submitLabel(.search)

            if !text.isEmpty {
                Button {
                    text = ""
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .font(.system(size: 14, weight: .medium))
                        .foregroundStyle(.tertiary)
                }
                .buttonStyle(.plain)
                .accessibilityLabel(clearLabel)
            }
        }
        .padding(.horizontal, 11)
        .frame(minHeight: 36)
        .background(
            Color(red: 0.04, green: 0.07, blue: 0.15).opacity(0.92),
            in: RoundedRectangle(cornerRadius: 10, style: .continuous)
        )
        .padding(.horizontal, AppTheme.pageInset)
        .padding(.vertical, 8)
        .background(.bar)
    }
}

struct AppLogo: View {
    var size: CGFloat = 44

    var body: some View {
        Group {
            if let icon = UIImage(named: "AppIcon60x60")
                ?? Bundle.main.path(forResource: "AppIcon60x60@2x", ofType: "png").flatMap(UIImage.init(contentsOfFile:))
                ?? UIImage(named: "AppIcon") {
                Image(uiImage: icon)
                    .resizable()
                    .scaledToFill()
            } else {
                Image(systemName: "slider.horizontal.3")
                    .font(.title2.weight(.semibold))
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(AppTheme.accent)
            }
        }
        .frame(width: size, height: size)
        .clipShape(RoundedRectangle(cornerRadius: size * 0.22, style: .continuous))
        .accessibilityHidden(true)
    }
}
