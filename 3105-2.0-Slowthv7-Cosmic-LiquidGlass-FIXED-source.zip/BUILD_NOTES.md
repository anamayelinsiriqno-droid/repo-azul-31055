# Build notes

This source includes a shared Xcode scheme at:

`ThreeOneOSFive.xcodeproj/xcshareddata/xcschemes/3105.xcscheme`

The project target/scheme name is `3105`.

For an unsigned CI archive:

```sh
xcodebuild -project ThreeOneOSFive.xcodeproj \
  -scheme 3105 \
  -configuration Release \
  -destination 'generic/platform=iOS' \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY='' \
  DEVELOPMENT_TEAM='' \
  clean archive
```
