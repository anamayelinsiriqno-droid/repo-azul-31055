Slowth Dark Fantasy UI patch

This patch changes only the UI layer files and adds one background asset:
- ThreeOneOSFive/views/DesignSystem.swift
- ThreeOneOSFive/views/FileBrowserView.swift
- ThreeOneOSFive/App.swift (copied unchanged for integration reference)
- Assets.xcassets/SlowthBackground.imageset/*

Visual target: black/crimson Dark Fantasy, Slowth header, liquid-glass file rows and search surface.
The existing file-browser operations and data layer are not replaced by this patch.

The included source tree is not an IPA build. Building an installable iOS IPA requires Xcode/iOS SDK and signing on macOS.
